package com.ufg.redes1.forca;

import java.util.Scanner;

/**
 *
 * @author Karine Pires de Araújo
 * @author Tayrone Cordeiro de Menezes Marques
 * @author Jonatas da Silva Oliveira
 */
public class ForcaPrincipal {
    public static void main(String[] args) throws Exception {
        int n;
        Scanner ler = new Scanner(System.in);
        boolean jahExisteCoord = false;
        
        do {
            System.out.println("Escolha entre as opcoes abaixo:");
            if(!jahExisteCoord)
                System.out.println("1 - Coordenador");
            System.out.println("2 - Jogador");
            System.out.println("3 - Sair");
            System.out.println("Escolha:");
            n = ler.nextInt();
            if(n == 1){
                new ServidorUDP("Karine", "Laranja").esperaPacotes();
                jahExisteCoord = true;
            }
            else if(n == 2) {
                new ClienteUDP();
            }
        } while (n != 3);
    }
}
