package com.ufg.redes1.forca;

import java.io.*;
import java.net.*;
import java.util.HashMap;

/**
 *
 * @author Karine Pires de Araújo
 * @author Tayrone Cordeiro de Menezes Marques
 * @author Jonatas da Silva Oliveira
 */
public class ClienteUDP {

    Jogador jogador = new Jogador();
    BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
    int porta = 9876;
    String servidor = "192.168.0.1";
    InetAddress IPAddress = InetAddress.getByName(servidor);
    byte[] sendData = new byte[1024];
    DatagramSocket clientSocket = new DatagramSocket();

    public ClienteUDP() throws Exception {
        this.iniciar();
    }

    public void iniciar() throws Exception {
        //System.out.println("Digite seu nome: ");
        //String nome = inFromUser.readLine();
        //jogador.setNome(nome);
        jogador.setEnderecoIP("localhost");
        jogador.setPorta(porta);
        jogador.setContChutesLetra(0);
        jogador.setContChutesPalavra(0);

        sendData = jogador.toString().getBytes();
        DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, porta);
        clientSocket.send(sendPacket);
        
        esperaPacotes();
    }

    public void esperaPacotes() throws SocketException, IOException {
        byte[] receiveData;

        while (true) {
            receiveData = new byte[1024];
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

            HashMap<String, Object> hashRecebido = new HashMap<>();
            String dadosRecebidos = new String(receivePacket.getData());
            hashRecebido = UtilsConverter.stringToHashMap(dadosRecebidos);

            if (hashRecebido.keySet().toArray()[0].equals("dica")) {
                System.out.println("Dica: " + hashRecebido.get("dica").toString());
            
            } else if (hashRecebido.keySet().toArray()[0].equals("suaVezLP")) {
                System.out.println(hashRecebido.get("suaVezLP").toString());
                String palavraLetraLida = inFromUser.readLine();
                
                enviaDatagramaParaOServidor(palavraLetraLida);
            } else if (hashRecebido.keySet().toArray()[0].equals("suaVezL")) {
                System.out.println(hashRecebido.get("suaVezL").toString());
                String letraLida = inFromUser.readLine();
                
                enviaDatagramaParaOServidor(letraLida);
            } else if(hashRecebido.keySet().toArray()[0].equals("palavraMontada")){
                System.out.println("Palavra: " + hashRecebido.get("palavraMontada").toString());
            } else if(hashRecebido.keySet().toArray()[0].equals("letrasDigitada")){
                System.out.println("Letras já digitadas: " + hashRecebido.get("palavraMontada").toString());
            } else if(hashRecebido.keySet().toArray()[0].equals("msg")){
                System.out.println(hashRecebido.get("msg").toString());
            }
        }
    }

    public void enviaDatagramaParaOServidor(String strLida) throws IOException {
        sendData = strLida.getBytes();
        DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, porta);
        clientSocket.send(sendPacket);
    }

}
