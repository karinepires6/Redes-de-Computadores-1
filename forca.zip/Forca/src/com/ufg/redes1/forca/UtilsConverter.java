package com.ufg.redes1.forca;

import java.util.HashMap;

/**
 *
 * @author karine
 */
public final class UtilsConverter {

    public static HashMap<String, Object> stringToHashMap(String s) {
        HashMap<String, Object> hm = new HashMap<String, Object>();
        for (String s1 : s.split(",")) {
            String[] s2 = s1.split(":");
            hm.put(s2[0], s2[1]);
        }

        return hm;
    }
    
    

}
