package com.ufg.redes1.forca;

/**
 *
 * @author Karine Pires de Araújo
 * @author Tayrone Cordeiro de Menezes Marques
 * @author Jonatas da Silva Oliveira
 */
public class Coordenador {
    private String nome;
    private String enderecoIP;
    private int porta;
    private String palavra;
    private String dica;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEnderecoIP() {
        return enderecoIP;
    }

    public void setEnderecoIP(String enderecoIP) {
        this.enderecoIP = enderecoIP;
    }

    public int getPorta() {
        return porta;
    }

    public void setPorta(int porta) {
        this.porta = porta;
    }

    public String getPalavra() {
        return palavra;
    }

    public void setPalavra(String palavra) {
        this.palavra = palavra;
    }

    public String getDica() {
        return dica;
    }

    public void setDica(String dica) {
        this.dica = dica;
    }
    
}
