package com.ufg.redes1.forca;

/**
 *
 * @author Karine Pires de Araújo
 * @author Tayrone Cordeiro de Menezes Marques
 * @author Jonatas da Silva Oliveira
 */
public class Jogador {
    private String nome;
    private String enderecoIP;
    private int porta;
    private int contChutesLetra;
    private int contChutesPalavra;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEnderecoIP() {
        return enderecoIP;
    }

    public void setEnderecoIP(String enderecoIP) {
        this.enderecoIP = enderecoIP;
    }

    public int getPorta() {
        return porta;
    }

    public void setPorta(int porta) {
        this.porta = porta;
    }

    public int getContChutesLetra() {
        return contChutesLetra;
    }

    public void setContChutesLetra(int contChutesLetra) {
        this.contChutesLetra = contChutesLetra;
    }

    public int getContChutesPalavra() {
        return contChutesPalavra;
    }

    public void setContChutesPalavra(int contChutesPalavra) {
        this.contChutesPalavra = contChutesPalavra;
    }

}
